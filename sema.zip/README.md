# istanbuldiagnostic-elsa-schema-synthetic-program
